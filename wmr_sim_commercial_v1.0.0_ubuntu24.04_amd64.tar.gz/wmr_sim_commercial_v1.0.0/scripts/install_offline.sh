#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "$(readlink -f -- "$0")")/.." && pwd)"
PROFILE=desktop
KEYRING=""
REQUIRE_SIGNATURE=0
while [ "$#" -gt 0 ]; do
  case "$1" in
    --profile) [ "$#" -ge 2 ] || { echo "--profile requires desktop|base" >&2; exit 2; }; PROFILE="$2"; shift 2 ;;
    --require-signature) REQUIRE_SIGNATURE=1; shift ;;
    --keyring) [ "$#" -ge 2 ] || { echo "--keyring requires FILE" >&2; exit 2; }; KEYRING="$2"; shift 2 ;;
    --yes|-y) shift ;;
    --help|-h) echo "Usage: sudo $0 [--profile desktop|base] [--yes] [--require-signature --keyring FILE]"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done
[ "$PROFILE" = desktop ] || [ "$PROFILE" = base ] || { echo "Invalid profile." >&2; exit 2; }
[ "$(id -u)" -eq 0 ] || { echo "Run with sudo." >&2; exit 1; }
[ -r /etc/os-release ] || { echo "Missing /etc/os-release." >&2; exit 1; }
. /etc/os-release
[ "$ID" = ubuntu ] && [ "$VERSION_ID" = 24.04 ] && [ "$(dpkg --print-architecture)" = amd64 ] || { echo "Supported platform: Ubuntu 24.04 amd64." >&2; exit 1; }
mkdir -p -m 0750 /var/log/wmrsim
LOG=/var/log/wmrsim/installer.log
exec > >(tee -a "$LOG") 2>&1
echo "[wmrsim] Offline install started: $(date -Is)"
[ -f "$ROOT/release_manifest.json" ] || { echo "Missing release manifest." >&2; exit 1; }
python3 - "$ROOT" <<'PY'
import hashlib, json, sys
from pathlib import Path
root=Path(sys.argv[1]).resolve()
manifest=json.loads((root/"release_manifest.json").read_text(encoding="utf-8"))
for item in manifest.get("artifacts", []):
    path=(root/item["path"]).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise SystemExit("Missing or invalid artifact: "+item.get("path","?"))
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""): h.update(chunk)
    if h.hexdigest()!=item["sha256"] or path.stat().st_size!=item["size_bytes"]:
        raise SystemExit("Integrity check failed: "+item["path"])
print("Release manifest verified.")
PY
if [ "$REQUIRE_SIGNATURE" -eq 1 ] || [ -f "$ROOT/release_manifest.json.asc" ]; then
  [ -n "$KEYRING" ] && [ -r "$KEYRING" ] || { echo "A trusted GPG keyring is required (--keyring)." >&2; exit 1; }
  gpg --no-default-keyring --keyring "$KEYRING" --verify "$ROOT/release_manifest.json.asc" "$ROOT/release_manifest.json"
fi
shopt -s nullglob
DEBS=("$ROOT"/offline-debs/*.deb)
[ "${#DEBS[@]}" -gt 0 ] || { echo "offline-debs/ must contain the complete dependency closure." >&2; exit 1; }
CORE=("$ROOT"/packages/ros-jazzy-wmr-sim-core_*.deb)
WHEELS=("$ROOT"/sdk/wmr_sim_sdk-*.whl)
[ "${#CORE[@]}" -eq 1 ] && [ "${#WHEELS[@]}" -eq 1 ] || { echo "Expected exactly one core .deb and SDK wheel." >&2; exit 1; }
echo "[wmrsim] Profile: $PROFILE"
echo "[wmrsim] APT will use --no-download; no network fallback is allowed."
apt-get --no-download install -y "${DEBS[@]}" "${CORE[0]}" python3-pip
python3 -m pip install --break-system-packages --no-deps --force-reinstall "${WHEELS[0]}"
[ -x /usr/bin/wmrsim ] || { echo "wmrsim CLI was not installed." >&2; exit 1; }
/usr/bin/wmrsim doctor
echo "[wmrsim] Offline installation completed. Log: $LOG"
