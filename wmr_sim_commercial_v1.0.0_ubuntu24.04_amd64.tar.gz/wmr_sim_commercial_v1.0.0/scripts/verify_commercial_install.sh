#!/usr/bin/env bash
# Strict post-install verification for wmrSim Commercial Edition.
set -Eeuo pipefail
fail() { echo "[DIAG] [FAIL] $*" >&2; exit 1; }
cd /
echo "[DIAG] ── 啟動 wmrSim 商業版安裝診斷 ──"
[ -f /opt/ros/jazzy/setup.bash ] || fail "找不到 ROS 2 Jazzy setup。"
# shellcheck disable=SC1091
set +u
source /opt/ros/jazzy/setup.bash
[ ! -r /opt/wmr_sim/overlay/local_setup.bash ] || source /opt/wmr_sim/overlay/local_setup.bash
set -u
command -v ros2 >/dev/null 2>&1 || fail "ROS 2 setup 未提供 ros2 指令。"
PACKAGE_STATUS="$(dpkg-query -W -f='${db:Status-Status}' ros-jazzy-wmr-sim-core 2>/dev/null)" || fail "找不到已安裝的 ros-jazzy-wmr-sim-core 套件。"
[ "$PACKAGE_STATUS" = installed ] || fail "核心套件狀態不是 installed：$PACKAGE_STATUS"
DEB_VER="$(dpkg-query -W -f='${Version}' ros-jazzy-wmr-sim-core)"
echo "[DIAG] [PASS] 核心套件已安裝（版本：$DEB_VER）"

TARGET_PKG_DIR="/opt/ros/jazzy/lib/python3.12/site-packages/wmr_sim"
[ -d "$TARGET_PKG_DIR" ] || fail "找不到核心模組目錄：$TARGET_PKG_DIR"
if find "$TARGET_PKG_DIR" -type f -name '*.py' -print -quit | grep -q .; then fail "核心模組目錄仍含 Python 原始碼檔案。"; fi
echo "[DIAG] [PASS] 核心目錄不含 .py 原始碼"

AMENT_MARKER="/opt/ros/jazzy/share/ament_index/resource_index/packages/wmr_sim"
[ -f "$AMENT_MARKER" ] || fail "缺少 ROS ament_index 套件標記：$AMENT_MARKER"
ros2 pkg prefix wmr_sim >/dev/null 2>&1 || fail "ROS 2 無法解析 wmr_sim 套件。"
ros2 pkg prefix dwb_plugins >/dev/null 2>&1 || fail "ROS 2 找不到執行相依套件：dwb_plugins"
MISSING_THIRD_PARTY=()
for ros_pkg in teb_local_planner costmap_converter; do
    ros2 pkg prefix "$ros_pkg" >/dev/null 2>&1 || MISSING_THIRD_PARTY+=("$ros_pkg")
done
if [ "${#MISSING_THIRD_PARTY[@]}" -gt 0 ]; then
    echo "[DIAG] [FAIL] 缺少第三方導航相依：${MISSING_THIRD_PARTY[*]}" >&2
    cat >&2 <<'EOF'
[DIAG] teb_local_planner 為核心 <exec_depend>，且不在 ROS 官方 apt 內，必須建置到
[DIAG] /opt/wmr_sim/overlay（wmrsim 與 wmrsim doctor 會自動 source 該處）。
[DIAG] 修復方式（擇一）：
[DIAG]   1) 重跑發行包內的第三方安裝器（線上或離線）：
[DIAG]        sudo bash <發行包>/scripts/install_third_party.sh --release-root <發行包>
[DIAG]   2) 手動（公開 SDK repo）：
[DIAG]        bash tools/fetch_third_party.sh --bundle --ws ~/wmr_sim_third_party_ws
[DIAG]        sudo apt-get install -y libg2o-dev libsuitesparse-dev libopencv-dev libboost-all-dev \
[DIAG]             ros-jazzy-nav2-core ros-jazzy-nav2-costmap-2d ros-jazzy-nav2-util ros-jazzy-nav2-msgs \
[DIAG]             ros-jazzy-cv-bridge ros-jazzy-eigen3-cmake-module ros-jazzy-tf2-eigen ros-jazzy-pluginlib \
[DIAG]             ros-jazzy-visualization-msgs build-essential cmake
[DIAG]        source /opt/ros/jazzy/setup.bash
[DIAG]        cd ~/wmr_sim_third_party_ws && colcon build --symlink-install --packages-select \
[DIAG]             costmap_converter_msgs costmap_converter teb_msgs teb_local_planner dwb_core dwb_critics dwb_plugins
[DIAG]        sudo mkdir -p /opt/wmr_sim/overlay && sudo cp -r ~/wmr_sim_third_party_ws/install/. /opt/wmr_sim/overlay/
[DIAG]   詳見 install.md 的「4.1 取得第三方導航相依（必要）」。
EOF
    exit 3
fi
echo "[DIAG] [PASS] ROS 2 核心與封裝 overlay 均可解析"
[ -x /usr/bin/wmrsim ] || fail "缺少 wmrSim CLI：/usr/bin/wmrsim"
[ -s /opt/wmr_sim/dashboard/index.html ] || fail "缺少 Dashboard 靜態入口。"
[ -f /usr/share/wmr_sim/integration_gateway.dashboard.yaml ] || fail "缺少 Dashboard gateway 設定。"
[ -f /usr/share/applications/wmrsim.desktop ] || fail "缺少桌面捷徑：/usr/share/applications/wmrsim.desktop"
echo "[DIAG] [PASS] CLI、桌面捷徑與 Dashboard 已安裝"

EXECUTABLES=(run_sim fleet_server fleet_client elevator_coordinator viz plugin_registry integration_gateway)
for bin in "${EXECUTABLES[@]}"; do
    if [ ! -x "/opt/ros/jazzy/lib/wmr_sim/$bin" ] && [ ! -x "/opt/ros/jazzy/bin/$bin" ]; then fail "缺少可執行節點：$bin"; fi
done
echo "[DIAG] [PASS] ${#EXECUTABLES[@]} 個核心 CLI/ROS 執行檔皆已就緒"

python3 - <<'PY'
try:
    import wmr_sim.sdk
    from wmr_sim.sdk.interfaces import BaseGlobalPlanner, BaseLocalController, BaseTrafficPlugin
    from wmr_sim.sdk.dataclasses import Pose2D, Twist2D
except Exception as exc:
    raise SystemExit(f"[DIAG] [FAIL] Customer SDK 導入失敗：{exc}")
print("[DIAG] [PASS] Customer SDK 導入成功")
PY
echo "[DIAG] ── 診斷完成：所有必要檢查通過 ──"
