#!/usr/bin/env bash
# ==============================================================================
# wmrSim 第三方導航相依安裝器
#
# 核心以 <exec_depend> 宣告 teb_local_planner 並在 plugin_registry 註冊，
# wmrsim doctor 亦強制檢查；而 teb_local_planner 與 costmap_converter 不在 ROS
# 官方 apt 內，必須另外取得並建置。
#
# 本腳本會：
#   1. 取得第三方原始碼包（--bundle 指定 → 發行包內 third_party/*.tar.gz → 線上來源）
#   2. 將原始碼佈署到工作區（build 於 --ws 指定的目錄）
#   3. 安裝系統相依（apt；teb 需要 g2o / suitesparse）
#   4. colcon build 七個套件
#   5. 將建置結果佈署到 overlay（預設 /opt/wmr_sim/overlay）
#      → wmrsim 與 wmrsim doctor 會自動 source 該處的 local_setup.bash
#   6. 驗收：source overlay 後 ros2 pkg prefix teb_local_planner 必須成功
#
# 注意：官方第三方發行包內的 install.sh 以 `set -euo pipefail` 執行後才 source
#       ROS setup 腳本，與 ROS 2 Jazzy 不相容（unbound variable），因此本腳本
#       **不呼叫**它，只把它當作原始碼來源，自行完成安裝與建置。
#
# 用法:
#   sudo bash scripts/install_third_party.sh [--release-root DIR] [--ws DIR]
#        [--overlay DIR] [--bundle FILE] [--offline] [--no-deps] [--no-build]
#
#   --no-deps   跳過系統相依安裝（相依已具備時）
#   --no-build  只佈署原始碼（乾跑、預先下載或自行建置時使用）
#   --offline   禁止網路下載；必須在發行包內 third_party/ 提供原始碼包
#
# 環境變數:
#   WMRSIM_THIRD_PARTY_URL      覆寫線上原始碼包來源 URL
#   WMRSIM_THIRD_PARTY_VERSION  版本（預設 1.0.0）
# ==============================================================================
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$(readlink -f -- "$0")")" && pwd)"
ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd)"

RELEASE_ROOT="${ROOT}"
WS_DIR=""
OVERLAY_DIR="/opt/wmr_sim/overlay"
BUNDLE_FILE=""
OFFLINE=0
DO_DEPS=1
DO_BUILD=1

RELEASE_VERSION="${WMRSIM_THIRD_PARTY_VERSION:-1.0.0}"
BUNDLE_NAME="wmr_sim_third_party_v${RELEASE_VERSION}.tar.gz"
DEFAULT_URL="https://github.com/jeffc168/wmrSim-public/releases/download/v${RELEASE_VERSION}/${BUNDLE_NAME}"

# 原始碼包內的頂層目錄（costmap_converter_msgs / teb_msgs 巢狀於其中）
BUNDLE_DIRS=(costmap_converter teb_local_planner dwb_core dwb_critics dwb_plugins)
# 需建置的 ROS 套件
PACKAGES=(costmap_converter_msgs costmap_converter teb_msgs teb_local_planner
          dwb_core dwb_critics dwb_plugins)
# 系統相依（teb_local_planner 需要 g2o 與 suitesparse）
APT_DEPS=(libg2o-dev libsuitesparse-dev libopencv-dev libboost-all-dev
          ros-jazzy-nav2-core ros-jazzy-nav2-costmap-2d ros-jazzy-nav2-util ros-jazzy-nav2-msgs
          ros-jazzy-cv-bridge ros-jazzy-eigen3-cmake-module ros-jazzy-tf2-eigen ros-jazzy-pluginlib
          ros-jazzy-visualization-msgs build-essential cmake)

usage() { sed -n '2,30p' "$0"; }
log()  { printf '[third-party] %s\n' "$*"; }
warn() { printf '[third-party][WARN] %s\n' "$*" >&2; }
die()  { printf '[third-party][ERROR] %s\n' "$*" >&2; exit 1; }

while [ "$#" -gt 0 ]; do
    case "$1" in
        --release-root) RELEASE_ROOT="$2"; shift 2 ;;
        --ws)           WS_DIR="$2"; shift 2 ;;
        --overlay)      OVERLAY_DIR="$2"; shift 2 ;;
        --bundle)       BUNDLE_FILE="$2"; shift 2 ;;
        --offline)      OFFLINE=1; shift ;;
        --no-deps)      DO_DEPS=0; shift ;;
        --no-build)     DO_BUILD=0; shift ;;
        -h|--help)      usage; exit 0 ;;
        *) die "未知參數：$1（--help 看用法）" ;;
    esac
done

if [ -z "${WS_DIR}" ]; then
    WS_DIR="$(mktemp -d)/wmrsim_third_party_ws"
fi
mkdir -p "$(dirname -- "${WS_DIR}")"

echo "======================================================================"
echo " wmrSim 第三方導航相依安裝器"
echo "   發行包根目錄: ${RELEASE_ROOT}"
echo "   建置工作區  : ${WS_DIR}"
echo "   overlay     : ${OVERLAY_DIR}"
echo "   離線模式    : ${OFFLINE}    系統相依: ${DO_DEPS}    建置: ${DO_BUILD}"
echo "======================================================================"

TMP_DIR="$(mktemp -d)"
cleanup() { rm -rf -- "${TMP_DIR}"; }
trap cleanup EXIT

# ---- 1. 取得原始碼包 -------------------------------------------------------
if [ -z "${BUNDLE_FILE}" ]; then
    candidate="$(ls -1t "${RELEASE_ROOT}"/third_party/wmr_sim_third_party_v*.tar.gz 2>/dev/null | head -n 1 || true)"
    if [ -n "${candidate}" ]; then
        BUNDLE_FILE="${candidate}"
        log "使用發行包內附的第三方原始碼包：${BUNDLE_FILE}"
    elif [ "${OFFLINE}" -eq 1 ]; then
        die "離線模式但找不到 ${RELEASE_ROOT}/third_party/${BUNDLE_NAME}；請於打包時以 WMRSIM_THIRD_PARTY_BUNDLE 納入，或改用線上安裝。"
    else
        BUNDLE_URL="${WMRSIM_THIRD_PARTY_URL:-${DEFAULT_URL}}"
        log "下載第三方原始碼包：${BUNDLE_URL}"
        curl -fL --retry 3 --connect-timeout 20 -o "${TMP_DIR}/${BUNDLE_NAME}" "${BUNDLE_URL}" \
            || die "下載失敗；請確認網路，或以 --bundle 指定本機原始碼包，或設定 WMRSIM_THIRD_PARTY_URL。"
        BUNDLE_FILE="${TMP_DIR}/${BUNDLE_NAME}"
    fi
fi
[ -f "${BUNDLE_FILE}" ] || die "找不到第三方原始碼包：${BUNDLE_FILE}"

# ---- 2. 解壓並佈署原始碼 ---------------------------------------------------
log "解壓 ${BUNDLE_FILE} ..."
tar -xzf "${BUNDLE_FILE}" -C "${TMP_DIR}" || die "解壓失敗：${BUNDLE_FILE}"
BUNDLE_ROOT="$(find "${TMP_DIR}" -mindepth 1 -maxdepth 1 -type d -name 'wmr_sim_third_party_v*' -print -quit)"
[ -n "${BUNDLE_ROOT}" ] || die "原始碼包結構異常（找不到 wmr_sim_third_party_v* 目錄）"

mkdir -p "${WS_DIR}/src"
for d in "${BUNDLE_DIRS[@]}"; do
    [ -d "${BUNDLE_ROOT}/src/${d}" ] || die "原始碼包缺少 src/${d}"
    rm -rf "${WS_DIR}/src/${d}"
    cp -r "${BUNDLE_ROOT}/src/${d}" "${WS_DIR}/src/"
    log "  + src/${d}"
done

# 授權合規：一併保留授權全文與第三方聲明
mkdir -p "${WS_DIR}/third_party_LICENSES"
cp -r "${BUNDLE_ROOT}/LICENSES/." "${WS_DIR}/third_party_LICENSES/" 2>/dev/null || true
cp "${BUNDLE_ROOT}/THIRD_PARTY.md" "${WS_DIR}/third_party_LICENSES/" 2>/dev/null || true
cp "${BUNDLE_ROOT}/patches/." "${WS_DIR}/third_party_LICENSES/" 2>/dev/null || true

# ---- 3. 系統相依 -----------------------------------------------------------
if [ "${DO_DEPS}" -eq 1 ]; then
    log "安裝系統相依（apt，需要網路與管理員權限）..."
    if [ "$(id -u)" -eq 0 ]; then
        apt-get update -qq || warn "apt-get update 失敗，仍嘗試安裝"
        apt-get install -y "${APT_DEPS[@]}" || die "系統相依安裝失敗（請確認網路／apt 來源）"
    else
        command -v sudo >/dev/null 2>&1 || die "需要管理員權限安裝系統相依（請以 sudo 執行本腳本，或使用 --no-deps）"
        sudo apt-get update -qq || warn "apt-get update 失敗，仍嘗試安裝"
        sudo apt-get install -y "${APT_DEPS[@]}" || die "系統相依安裝失敗（請確認網路／apt 來源）"
    fi
else
    log "略過系統相依安裝（--no-deps）"
fi

# ---- 4. 建置 ---------------------------------------------------------------
if [ "${DO_BUILD}" -eq 1 ]; then
    [ -d /opt/ros/jazzy ] || die "找不到 ROS 2 Jazzy（/opt/ros/jazzy）"
    log "colcon build（${#PACKAGES[@]} 個套件）..."
    set +u   # ROS setup 腳本不相容 set -u
    # shellcheck disable=SC1091
    source /opt/ros/jazzy/setup.bash
    set -u
    ( cd "${WS_DIR}" && colcon build --symlink-install --packages-select "${PACKAGES[@]}" ) \
        || die "colcon build 失敗；請檢視上方輸出（常見原因：缺少 libg2o-dev / libsuitesparse-dev）"
else
    log "略過建置（--no-build）"
fi

# ---- 5. 佈署 overlay -------------------------------------------------------
if [ ! -d "${WS_DIR}/install" ]; then
    if [ "${DO_BUILD}" -eq 0 ]; then
        warn "已指定 --no-build 且未產生 ${WS_DIR}/install → 略過 overlay 佈署與驗收。"
        warn "完成建置後請重跑本腳本，或手動： sudo cp -r ${WS_DIR}/install/. ${OVERLAY_DIR}/"
    else
        die "建置完成但找不到 ${WS_DIR}/install → 建置未成功產出 install tree。"
    fi
else
    log "佈署 overlay → ${OVERLAY_DIR}"
    # 若目標已可寫（例如自訂 --overlay 到使用者目錄），就不需要 sudo
    if [ "$(id -u)" -eq 0 ] || [ -w "${OVERLAY_DIR}" ] \
       || { [ ! -e "${OVERLAY_DIR}" ] && [ -w "$(dirname -- "${OVERLAY_DIR}")" ]; }; then
        install -d -m 0755 "${OVERLAY_DIR}"
        cp -r "${WS_DIR}/install/." "${OVERLAY_DIR}/"
        if [ -d "${WS_DIR}/third_party_LICENSES" ]; then
            cp -r "${WS_DIR}/third_party_LICENSES" "${OVERLAY_DIR}/" 2>/dev/null || true
        fi
    else
        command -v sudo >/dev/null 2>&1 || die "需要管理員權限佈署 ${OVERLAY_DIR}（請以 sudo 執行本腳本）"
        sudo install -d -m 0755 "${OVERLAY_DIR}"
        sudo cp -r "${WS_DIR}/install/." "${OVERLAY_DIR}/"
        if [ -d "${WS_DIR}/third_party_LICENSES" ]; then
            sudo cp -r "${WS_DIR}/third_party_LICENSES" "${OVERLAY_DIR}/" 2>/dev/null || true
        fi
    fi
fi

# ---- 6. 驗收 ---------------------------------------------------------------
if [ -r "${OVERLAY_DIR}/local_setup.bash" ]; then
    log "驗收：以 ${OVERLAY_DIR}/local_setup.bash 檢查 ROS 套件解析..."
    set +u
    # shellcheck disable=SC1091
    source /opt/ros/jazzy/setup.bash
    # shellcheck disable=SC1091
    source "${OVERLAY_DIR}/local_setup.bash"
    set -u
    missing=()
    for p in teb_local_planner costmap_converter dwb_plugins; do
        ros2 pkg prefix "$p" >/dev/null 2>&1 || missing+=("$p")
    done
    if [ "${#missing[@]}" -gt 0 ]; then
        die "驗收失敗：${missing[*]} 無法解析（建置可能未完成；請檢視 ${WS_DIR} 的 colcon 輸出）"
    fi
    log "✅ 第三方導航相依已就緒（teb_local_planner / costmap_converter / dwb_plugins）"
else
    warn "尚未佈署 overlay（${OVERLAY_DIR}/local_setup.bash 不存在）→ 略過驗收。"
fi

echo
log "完成。wmrsim 與 wmrsim doctor 會自動 source ${OVERLAY_DIR}/local_setup.bash。"
