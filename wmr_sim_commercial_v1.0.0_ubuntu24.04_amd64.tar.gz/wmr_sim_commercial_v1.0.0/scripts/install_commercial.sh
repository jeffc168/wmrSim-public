#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_PATH="$(readlink -f -- "$0")"
SCRIPT_DIR="$(cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd)"
RELEASE_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"
CURRENT_STEP="preflight"
PROFILE=""
AUTO_YES=0
TMP_ROS_DEB=""
trap 'rm -f "$TMP_ROS_DEB"' EXIT
trap 'status=$?; line=$LINENO; echo "[ERROR] 安裝在「$CURRENT_STEP」失敗（退出碼 $status，行 $line）。" >&2; exit "$status"' ERR
fail() { echo "[ERROR] $*" >&2; exit 1; }
run_privileged() { if [ "$(id -u)" -eq 0 ]; then "$@"; else sudo "$@"; fi; }
usage() {
  echo "用法：$0 [--profile desktop|base] [--yes]"
  echo "  --profile desktop  安裝含 RViz 的 ROS 桌面環境（預設）"
  echo "  --profile base     安裝較精簡的 ROS 與模擬依賴，適用 headless"
  echo "  --yes              自動接受安裝 ROS（若缺少）"
}
while [ "$#" -gt 0 ]; do
  case "$1" in
    --profile) [ "$#" -ge 2 ] || fail "--profile 需要 desktop 或 base"; PROFILE="$2"; shift 2 ;;
    --yes|-y) AUTO_YES=1; shift ;;
    --help|-h) usage; exit 0 ;;
    *) fail "未知參數：$1" ;;
  esac
done
[ -z "$PROFILE" ] || [ "$PROFILE" = desktop ] || [ "$PROFILE" = base ] || fail "profile 只能是 desktop 或 base。"
echo "wmrSim 企業版一鍵安裝：Ubuntu 24.04 LTS / amd64"
CURRENT_STEP="系統與發行包檢查"
[ -r /etc/os-release ] || fail "找不到 /etc/os-release。"
. /etc/os-release
[ "$ID" = ubuntu ] && [ "$VERSION_ID" = 24.04 ] || fail "只支援 Ubuntu 24.04；偵測到 $PRETTY_NAME。"
[ "$(dpkg --print-architecture)" = amd64 ] || fail "只支援 amd64 架構。"
for tool in apt-get dpkg dpkg-deb dpkg-query python3 readlink; do
  command -v "$tool" >/dev/null 2>&1 || fail "缺少必要指令：$tool"
done
if [ "$(id -u)" -ne 0 ]; then
  command -v sudo >/dev/null 2>&1 || fail "需要 sudo 權限安裝系統套件。"
  sudo -v
fi
shopt -s nullglob
[ -f "$RELEASE_ROOT/release_manifest.json" ] || fail "Missing release_manifest.json."
python3 - "$RELEASE_ROOT" <<'PYEOF'
import hashlib
import json
import sys
from pathlib import Path
root = Path(sys.argv[1]).resolve()
manifest = json.loads((root / "release_manifest.json").read_text(encoding="utf-8"))
for item in manifest.get("artifacts", []):
    path = (root / item["path"]).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise SystemExit(f"[ERROR] Missing or invalid release path: {item.get('path')}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != item["sha256"] or path.stat().st_size != item["size_bytes"]:
        raise SystemExit(f"[ERROR] Release integrity check failed: {item['path']}")
print("Release integrity check passed.")
PYEOF
DEB_CANDIDATES=("$RELEASE_ROOT"/packages/ros-jazzy-wmr-sim-core_*.deb)
[ "${#DEB_CANDIDATES[@]}" -eq 1 ] || fail "需要且只能有一個核心 .deb；找到 ${#DEB_CANDIDATES[@]} 個。"
DEB_FILE="${DEB_CANDIDATES[0]}"
[ "$(dpkg-deb -f "$DEB_FILE" Package)" = ros-jazzy-wmr-sim-core ] || fail "核心 .deb 套件名稱錯誤。"
[ "$(dpkg-deb -f "$DEB_FILE" Architecture)" = amd64 ] || fail "核心 .deb 架構不符。"
SDK_CANDIDATES=("$RELEASE_ROOT"/sdk/wmr_sim_sdk-*.whl)
[ "${#SDK_CANDIDATES[@]}" -eq 1 ] || fail "需要且只能有一個 SDK wheel；找到 ${#SDK_CANDIDATES[@]} 個。"
SDK_WHL="${SDK_CANDIDATES[0]}"

if [ ! -f /opt/ros/jazzy/setup.bash ]; then
  CURRENT_STEP="ROS 2 Jazzy 安裝確認"
  if [ "$AUTO_YES" -ne 1 ] && [ -t 0 ]; then
    if [ -z "$PROFILE" ]; then
      printf "選擇 ROS profile [desktop/base，預設 desktop]："
      read -r PROFILE || true
      PROFILE="${PROFILE:-desktop}"
    fi
    printf "尚未安裝 ROS 2 Jazzy。設定官方 ROS apt 來源並安裝 ROS 與 wmrSim 依賴？[Y/n] "
    read -r answer || true
    case "${answer:-Y}" in n|N|no|NO) fail "已取消。安裝 ROS 2 Jazzy 後再重試。" ;; esac
  fi
  PROFILE="${PROFILE:-desktop}"
  [ "$PROFILE" = desktop ] || [ "$PROFILE" = base ] || fail "profile 只能是 desktop 或 base。"
  CURRENT_STEP="官方 ROS apt 來源設定"
  run_privileged apt-get update
  run_privileged apt-get install -y curl ca-certificates software-properties-common
  run_privileged add-apt-repository -y universe
  ROS_SOURCE_DEB="$(python3 -c 'import json,sys; r=json.load(sys.stdin); print(next(a["browser_download_url"] for a in r["assets"] if a["name"].endswith(".noble_all.deb")))' < <(curl -fsSL https://api.github.com/repos/ros-infrastructure/ros-apt-source/releases/latest))" || fail "無法從官方 ros-apt-source 發布資訊找到 Ubuntu Noble 套件。"
  [ -n "$ROS_SOURCE_DEB" ] || fail "官方 ROS apt 來源套件網址為空。"
  TMP_ROS_DEB="$(mktemp --suffix=.deb)"
  curl -fL "$ROS_SOURCE_DEB" -o "$TMP_ROS_DEB"
  run_privileged apt-get install -y "$TMP_ROS_DEB"
  rm -f "$TMP_ROS_DEB"
else
  echo "ROS 2 Jazzy 已存在，檢查並補齊選定 profile。"
fi

PROFILE="${PROFILE:-desktop}"
CURRENT_STEP="ROS 2 與 wmrSim 相依套件安裝"
run_privileged apt-get update
if [ "$PROFILE" = desktop ]; then
  run_privileged apt-get install -y ros-jazzy-desktop ros-jazzy-navigation2 ros-jazzy-nav2-bringup ros-jazzy-nav2-regulated-pure-pursuit-controller
else
  run_privileged apt-get install -y ros-jazzy-ros-base ros-jazzy-navigation2 ros-jazzy-nav2-bringup ros-jazzy-nav2-regulated-pure-pursuit-controller
fi

CURRENT_STEP="核心套件與系統依賴安裝"
run_privileged apt-get install -y "$DEB_FILE" python3-pip
CURRENT_STEP="客戶端 SDK 安裝"
run_privileged python3 -m pip install --break-system-packages --no-deps --force-reinstall "$SDK_WHL"
CURRENT_STEP="第三方導航相依安裝（teb_local_planner / costmap_converter）"
bash "${RELEASE_ROOT}/scripts/install_third_party.sh" --release-root "${RELEASE_ROOT}" \
  || fail "第三方導航相依安裝失敗：核心以 exec_depend 宣告 teb_local_planner，缺少時導航外掛無法載入。"

CURRENT_STEP="安裝結果診斷"
[ -x /usr/bin/wmrsim ] || fail "核心套件未提供 /usr/bin/wmrsim；請重新產生 M2 核心套件。"
/usr/bin/wmrsim doctor
echo "安裝完成。執行 wmrsim start 啟動模擬與 Dashboard（http://127.0.0.1:8080/）；無桌面使用 wmrsim start --headless；診斷：wmrsim doctor。"
