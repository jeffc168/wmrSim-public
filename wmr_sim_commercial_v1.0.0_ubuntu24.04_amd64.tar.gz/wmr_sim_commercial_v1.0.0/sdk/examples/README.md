# wmrSim Customer Plugin SDK 開發範例

本目錄提供使用 `wmr-sim-sdk` 開發自訂移動機器人演算法外掛的標準範例。

## 內容清單

- `custom_astar_planner.py`：實作 `BaseGlobalPlanner` 的全域規劃器範例。
- `custom_rpp_controller.py`：實作 `BaseLocalController` 的局部控制器範例。
- `config/plugin_manifest.json`：外掛設定宣告檔案。

## 安裝 SDK

```bash
pip install wmr_sim_sdk-1.0.0-py3-none-any.whl
```

## 開發與註冊方式

### 1. 定義您的類別並繼承 SDK 介面
```python
from wmr_sim.sdk.interfaces import BaseGlobalPlanner
from wmr_sim.sdk.dataclasses import Pose2D

class MyPlanner(BaseGlobalPlanner):
    def initialize(self, config):
        pass
    def plan_path(self, start_pose, goal_pose, costmap=None, obstacles=None):
        return [{"x": goal_pose.x, "y": goal_pose.y, "yaw": 0.0}]
```

### 2. 透過 RESTful API 動態注入外掛
```bash
curl -X POST http://127.0.0.1:8080/api/v1/plugins/register \
  -H "Content-Type: application/json" \
  -d @config/plugin_manifest.json
```

### 3. GUI 即時切換
開啟 `wmr_sim` 控制中心 GUI，左側「控制器設定」下拉選單將自動出現新註冊的外掛，點選即可熱切換！
