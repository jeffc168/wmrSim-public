# 新手外掛演算法 Package 設計與開發指南 (Plugin Package Design Guide)

本文件專為演算法工程師與新進開發者編寫，提供如何在不修改 wmrSim 核心二進位套件前提下，獨立設計、實作、打包與動態註冊自訂 **Global Planner（全域規劃器）**、**Local Controller（局部控制器）** 與 **Traffic Manager（交通管理器）** 外掛演算法。

---

## 1. 外掛架構總覽 (Plugin Architecture)

wmrSim 核心以無原始碼（純 Bytecode 二進位 `.deb` 套件）獨立發布與維護。外部自訂演算法透過 **Customer SDK** 抽象基底類別定義，並由 **Plugin Registry 註冊中心** 提供動態探測與註冊服務。

```text
[自訂演算法 Package] ──(Manifest / REST / ament_index)──> [Plugin Registry]
                                                               │
                                                               ▼
[HAL / Nav2 / 邊緣體系] <──(熱切換 Algorithm Switched)── [GUI 下拉選單]
```

---

## 2. 三大外掛插槽與 SDK 介面規格

所有的外掛均繼承自 `wmr_sim.sdk.interfaces`：

### 2.1 全域路徑規劃器 (`BaseGlobalPlanner`)
- **用途**：在全域靜態網格或拓撲地圖中計算避開障礙物的航點列表。
- **介面定義**：
```python
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from wmr_sim.sdk.dataclasses import Pose2D

class BaseGlobalPlanner(ABC):
    @abstractmethod
    def initialize(self, config: Dict[str, Any]) -> None:
        pass

    @abstractmethod
    def plan_path(
        self,
        start_pose: Pose2D,
        goal_pose: Pose2D,
        costmap: Optional[Any] = None,
        obstacles: Optional[List[Dict[str, float]]] = None
    ) -> List[Dict[str, float]]:
        """回傳航點字典列表: [{'x': 1.0, 'y': 2.0, 'yaw': 0.0}, ...]"""
        pass
```

### 2.2 局部避障控制器 (`BaseLocalController`)
- **用途**：即時依據局部代價地圖、LiDAR 掃描與 3D 深度點雲計算車體線速度與角速度。
- **介面定義**：
```python
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from wmr_sim.sdk.dataclasses import Pose2D, Twist2D

class BaseLocalController(ABC):
    @abstractmethod
    def initialize(self, config: Dict[str, Any]) -> None:
        pass

    @abstractmethod
    def set_plan(self, path: List[Dict[str, float]]) -> None:
        pass

    @abstractmethod
    def compute_velocity(
        self,
        robot_pose: Pose2D,
        current_vel: Twist2D,
        local_costmap: Optional[Any] = None,
        obstacles: Optional[List[Dict[str, float]]] = None
    ) -> Twist2D:
        """回傳線速度與角速度: Twist2D(linear=0.5, angular=0.1)"""
        pass
```

### 2.3 交通調度管理器 (`BaseTrafficPlugin`)
- **用途**：仲裁多車在狹窄路網、十字路口與單向走廊的通行權與時空預約。
- **介面定義**：
```python
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any

class BaseTrafficPlugin(ABC):
    @abstractmethod
    def initialize(self, config: Dict[str, Any]) -> None:
        pass

    @abstractmethod
    def resolve_conflicts(
        self,
        robots: List[Dict[str, Any]],
        current_reservations: Dict[str, Any],
        network_topology: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """回傳更新後的時空預約租約狀態"""
        pass
```

---

## 3. 外掛 Package 標準目錄結構

```text
my_wmr_plugins/
├── config/
│   └── my_plugins.json             <-- 外掛宣告 Manifest (遵循 plugin_manifest_v1.schema.json)
├── my_wmr_plugins/
│   ├── __init__.py
│   ├── custom_astar_planner.py     <-- 實作 BaseGlobalPlanner
│   └── custom_rpp_controller.py    <-- 實作 BaseLocalController
├── package.xml                     <-- ROS 2 套件資訊
├── setup.py                        <-- 資源安裝與 ament_index 註冊
└── setup.cfg
```

### Manifest 範例 (`config/my_plugins.json`)
```json
{
  "plugin_id": "customer_fast_astar",
  "name": "Customer High-Speed A* Planner",
  "version": "1.0.0",
  "plugin_type": "GLOBAL_PLANNER",
  "entrypoint": "my_wmr_plugins.custom_astar_planner:CustomerAStarPlanner",
  "author": "Your Team",
  "description": "自訂跳躍點 A* 全域規劃器"
}
```

---

## 4. 外掛動態註冊與熱切換流程

### 方式 A: Gateway RESTful API 動態注入
```bash
curl -X POST http://127.0.0.1:8080/api/v1/plugins/register \
  -H "Content-Type: application/json" \
  -d '{
    "plugin_id": "customer_fast_astar",
    "name": "Customer High-Speed A* Planner",
    "version": "1.0.0",
    "plugin_type": "GLOBAL_PLANNER",
    "entrypoint": "my_wmr_plugins.custom_astar_planner:CustomerAStarPlanner"
  }'
```

### 方式 B: ROS 2 Topic 即時熱切換
```bash
ros2 topic pub --once /wmr_sim/switch_algorithm std_msgs/msg/String \
  '{data: "{\"robot_id\": \"wmr_0\", \"plugin_type\": \"GLOBAL_PLANNER\", \"plugin_id\": \"customer_fast_astar\"}"}'
```

---

## 5. GUI 視覺化與 3D 視覺 / HAL 聯動

1. **控制器下拉選單**：完成註冊後，GUI 左側「控制器設定」面板的 Planner / Controller 下拉選單將自動填入該外掛名稱，點選即可即時切換。
2. **3D 視覺浮動控制面板 (VisionControlDock)**：
   - 預設提供「近處 (3-10m) 避障輔助」與「已知 Tag 輔助定位」演算法開關（預設皆關閉）。
   - 支援拖曳為獨立浮動視窗，並記憶個別車輛之開關狀態。
3. **Sim / Real HAL 底盤切換**：
   - `hal_mode: "sim"`：純模擬差速積分。
   - `hal_mode: "real"`：透過 MQTT 對接 AGV2W 邊緣網關 (`agv_fleet_gateway`)，下發控制至實體車控制體系。

---

## 6. 研發守則與驗證指令

- **守則 1**：程式有問題一定先 review 最新 log（`~/.wmr_sim/logs/` 與 `~/.ros/log/`）。
- **守則 2**：修訂認可版本記錄到 `revision.md`。
- **守則 3**：螢幕輸出維持精簡，Launch 節點配置 `output="log"`。
- **守則 4**：啟動自動檢查 log 目錄，嚴格保留最新 50 筆。

### 驗證指令
```bash
# 執行外掛 SDK 與五步流程回歸測試
pytest test/test_customer_sdk.py test/test_e2e_customer_workflow.py -v

# 啟動模擬環境與視覺化介面
bash launch_nav2.bash gui:true
```
