# wmrSim 企業版 (Commercial Edition) 開箱指南

歡迎使用 wmrSim 企業商業版。本套件提供完整的多機器人數位分身模擬、Open-RMF 交通管制、跨樓層電梯協同與企業網關。

## 目錄結構說明

- `packages/`：核心預編譯二進位套件 (`ros-jazzy-wmr-sim-core_*.deb`)，採零原始碼 Bytecode 發行。
- `third_party/`：第三方導航相依原始碼包（teb_local_planner / costmap_converter / dwb_*；可選，供離線安裝）。
- `sdk/`：客戶端 Plugin SDK Wheel 套件與開發範例。
- `config/`：企業現場標準設定檔與網關設定。
- dashboard/：由核心套件安裝的 Web Dashboard 靜態資源。
- `docs/`：商業解決方案建議書、EULA 授權合約及技術手冊。
- `scripts/`：自動化安裝與診斷工具。
- `release_manifest.json`：發行檔案 SHA-256 雜湊與完整性憑證。

## 系統需求與快速安裝

一般使用者請從 Release 下載主要單檔 .run，依該版本檔名執行：bash <下載的安裝器.run> --profile desktop。替代 tar.gz 可解壓後執行 bash ./install.sh --profile desktop。

支援 Ubuntu 24.04 LTS amd64。安裝器可設定官方 ROS apt 來源，並安裝 Jazzy、Nav2 及桌面或 headless profile。核心 .deb 提供模擬核心與 Dashboard 靜態資產；**第三方導航相依（teb_local_planner、costmap_converter、dwb_*）不在 .deb 內**，由安裝器以 `scripts/install_third_party.sh` 取得並建置後佈署到 `/opt/wmr_sim/overlay`（核心 exec_depend 必需）。

安裝完成後執行 wmrsim start，啟動模擬與 Dashboard；Dashboard 網址為 http://127.0.0.1:8080/。伺服器使用 wmrsim start --headless，診斷使用 wmrsim doctor。

